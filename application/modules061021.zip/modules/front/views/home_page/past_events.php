<!--sub banner
    ================================================== -->
  <div class="sub-banner text-center" style="background-image:url(<?php echo base_url()?>assets/front/sub-images/about-bnr.jpg)">
    <div class="container">
      <h1>PAST EVENTS</h1>
    </div>  
  </div> <!-- sub banner --> 
  
  
  <h1 style="font-family:42px; text-align:center; padding:50px 0; color:#000; text-transform:uppercase;">under construction</h1>
<!--<div class="from-bg">
    <div class="container pad-b48">
        <div class="row shadow bg-1">
            <h1 style="font-family:42px; text-align:center; padding:50px 0; color:#000; text-transform:uppercase;">under construction</h1>
        </div>
    </div>
</div>  from-bg end-->

