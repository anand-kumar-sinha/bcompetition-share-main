<!--sub banner
    ================================================== -->
  <div class="sub-banner text-center" style="background-image:url(<?php echo base_url()?>assets/front/sub-images/about-bnr.jpg)">
    <div class="container">
      <h1>SUPPORTERS OF VPAG</h1>
    </div>  
  </div> <!-- sub banner --> 


<div class="from-bg">
    <div class="container pad-b48">
      <div class="row shadow bg-1">
        <div class="sub-cont contact">
          <div class="row pad-t14">
            <div class="col-sm-12 col-xs-12"> 
                <ul class="list-inline supporters">

                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/66.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/1.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/67.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/6.jpg" class="img-responsive" alt=""></li>
                    <li class="bor-none"><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/12.jpg" class="img-responsive" alt=""></li>



                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/19.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/7.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/11.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/38.jpg" class="img-responsive" alt=""></li>
                    <li  class="bor-none"><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/34.jpg" class="img-responsive" alt=""></li>


                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/9.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/24.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/42.jpg" class="img-responsive" alt=""></li>
                    <li ><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/16.jpg" class="img-responsive" alt=""></li>
                    <li class="bor-none"><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/25.jpg" class="img-responsive" alt=""></li>

                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/45.jpg" class="img-responsive" alt=""></li>
                    <li ><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/15.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/5.jpg" class="img-responsive" alt=""></li>
                    <li ><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/46.jpg" class="img-responsive" alt=""></li>
                    <li class="bor-none"><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/44.jpg" class="img-responsive" alt=""></li>



                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/64.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/63.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/10.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/50.jpg" class="img-responsive" alt=""></li>
                    <li class="bor-none"><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/27.jpg" class="img-responsive" alt=""></li>

                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/30.jpg" class="img-responsive" alt=""></li>
                    <li ><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/28.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/31.jpg" class="img-responsive" alt=""></li>
                    <li ><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/33.jpg" class="img-responsive" alt=""></li>
                    <li class="bor-none"><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/36.jpg" class="img-responsive" alt=""></li>




                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/32.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/43.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/47.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/65.jpg" class="img-responsive" alt=""></li>
                    <li  class="bor-none"><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/48.jpg" class="img-responsive" alt=""></li>



                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/51.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/52.jpg" class="img-responsive" alt=""></li>
                    <li ><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/53.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/54.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/55.jpg" class="img-responsive" alt=""></li>


                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/56.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/57.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/58.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/59.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/60.jpg" class="img-responsive" alt=""></li>


                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/61.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/62.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/2.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/4.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/8.jpg" class="img-responsive" alt=""></li>


                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/14.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/17.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/20.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/21.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/22.jpg" class="img-responsive" alt=""></li>


                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/23.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/26.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/29.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/35.jpg" class="img-responsive" alt=""></li>
                    <li class="bor-none"><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/37.jpg" class="img-responsive" alt=""></li>

                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/39.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/40.jpg" class="img-responsive" alt=""></li>
                    <li><img src="<?php echo base_url()?>assets/front/sub-images/supporters-logo/41.jpg" class="img-responsive" alt=""></li>
                </ul>
                </div>
            </div>
        </div>
        </div>
    </div>  <!--from-bg end-->
</div>