<!--sub banner
    ================================================== -->
  <div class="sub-banner text-center" style="background-image:url(<?php echo base_url()?>assets/front/sub-images/about-bnr.jpg)">
    <div class="container">
      <h1>ABOUT US</h1>
    </div>  
  </div> <!-- sub banner --> 


<div class="from-bg">
  <div class="container pad-b48">
    <div class="row shadow bg-1">
      <div class="sub-cont about">
         <p>VPAG � Video Photographers Association of Gujarat a name well known in the field of Photography. The Association was formed in 2004 Oct. by leading photographers of Ahmedabad with a motive of social responsibility for the fraternity. One of the only Registered Association under Charity Commissioner of Gujarat & one of the few Association of India which is registered. With a strength of more then 750 odd life members all from the field of Photography & Videography.</p>	
        <p>The Association has been a benchmark for creating the best of the workshops for its members by conducting workshops & talk-shows of Senior & Renowned 
        Photographers. Association also have tried to cover variety of subjects from basic photography, basic knowledge of camera, advance editing, marketing, 
        videography, candid photography & videography, pre wedding shoot and much more.</p>	
        
         <div class="our-mison">
            <h1>OUR MISSION</h1>
            <p>Reach to the smallest of the person of the industry - Conduct more & more workshops and increase the knowledge of photographers & 
            videographers Make Gujarat the hub of Photography & Videography.</p>
            <h3>Together We Share the Thoughts...</h3>
        </div>
      </div>
    </div>
  </div>
</div>  <!--from-bg end-->