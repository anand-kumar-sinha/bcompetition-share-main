<!--sub banner
    ================================================== -->
  <div class="sub-banner text-center" style="background-image:url(<?php echo base_url()?>assets/front/sub-images/about-bnr.jpg)">
    <div class="container">
      <h1>EVENTS</h1>
    </div>  
  </div> <!-- sub banner --> 
  
  
  
  <div class="from-bg">
  <div class="container pad-b48">
    <div class="row shadow bg-1">
      <div class="sub-cont committee"><h1 class="text-center">2015 AIFF HIGHLIGHTS</h1>
        <div class="row">
          <div class="col-sm-3 col-ms-6 col-xs-12">
            <div class="guests">
                <img src="<?php echo base_url()?>assets/front/sub-images/high-3.jpg" class="img-responsive" title="Pankaj Patel" alt="Hideihiko Tanaka"> 
                <a href="<?php echo base_url()?>assets/front/sub-images/high-3.jpg" class="fancybox" data-fancybox-group="gallery">
                <span class="hover-content"><i class="fa fa-expand"></i></span></a>
              </div>
            </div>
            <div class="col-sm-3 col-ms-6 col-xs-12">
              <div class="guests">
                <img src="<?php echo base_url()?>assets/front/sub-images/high-4.jpg" class="img-responsive" title="PVN Moorthy" alt="PVN Moorthy"> 
                <a href="<?php echo base_url()?>assets/front/sub-images/high-4.jpg" class="fancybox" data-fancybox-group="gallery">
                <span class="hover-content"><i class="fa fa-expand"></i></span></a>
              </div>
            </div>
            <div class="col-sm-3 col-ms-6 col-xs-12">
              <div class="guests">
                <img src="<?php echo base_url()?>assets/front/sub-images/high-5.jpg" class="img-responsive" title="Jai Narayan Vyas" alt="Jai Narayan Vyas"> 
                <a href="<?php echo base_url()?>assets/front/sub-images/high-5.jpg" class="fancybox" data-fancybox-group="gallery">
                <span class="hover-content"><i class="fa fa-expand"></i></span></a>
              </div>
            </div>
            <div class="col-sm-3 col-ms-6 col-xs-12">
              <div class="guests">
                <img src="<?php echo base_url()?>assets/front/sub-images/high-6.jpg" class="img-responsive" title="Mangaldas Patel" alt="Mangaldas Patel"> 
                <a href="<?php echo base_url()?>assets/front/sub-images/high-6.jpg" class="fancybox" data-fancybox-group="gallery">
                <span class="hover-content"><i class="fa fa-expand"></i></span></a>
              </div>
            </div>
            <div class="col-sm-3 col-ms-6 col-xs-12">
              <div class="guests">
                <img src="<?php echo base_url()?>assets/front/sub-images/high-7.jpg" class="img-responsive" title="Mangaldas Patel" alt="Mangaldas Patel"> 
                <a href="<?php echo base_url()?>assets/front/sub-images/high-7.jpg" class="fancybox" data-fancybox-group="gallery">
                <span class="hover-content"><i class="fa fa-expand"></i></span></a>
              </div>
            </div>
            <div class="col-sm-3 col-ms-6 col-xs-12">
              <div class="guests">
                <img src="<?php echo base_url()?>assets/front/sub-images/high-8.jpg" class="img-responsive" title="Mangaldas Patel" alt="Mangaldas Patel"> 
                <a href="<?php echo base_url()?>assets/front/sub-images/high-8.jpg" class="fancybox" data-fancybox-group="gallery">
                <span class="hover-content"><i class="fa fa-expand"></i></span></a>
              </div>
            </div>
            <div class="col-sm-3 col-ms-6 col-xs-12">
              <div class="guests">
                <img src="<?php echo base_url()?>assets/front/sub-images/high-10.jpg" class="img-responsive" title="Mangaldas Patel" alt="Mangaldas Patel"> 
                <a href="<?php echo base_url()?>assets/front/sub-images/high-10.jpg" class="fancybox" data-fancybox-group="gallery">
                <span class="hover-content"><i class="fa fa-expand"></i></span></a>
              </div>
            </div>
            <div class="col-sm-3 col-ms-6 col-xs-12">
              <div class="guests">
                <img src="<?php echo base_url()?>assets/front/sub-images/high-11.jpg" class="img-responsive" title="Mangaldas Patel" alt="Mangaldas Patel"> 
                <a href="<?php echo base_url()?>assets/front/sub-images/high-11.jpg" class="fancybox" data-fancybox-group="gallery">
                <span class="hover-content"><i class="fa fa-expand"></i></span></a>
              </div>
            </div>
          </div><!--HIGHLIGHTS end-->
      </div>
    </div>
  </div>
</div>  <!--from-bg end-->

