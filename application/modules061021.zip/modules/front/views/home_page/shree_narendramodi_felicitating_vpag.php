<!--sub banner
    ================================================== -->
  <div class="sub-banner text-center" style="background-image:url(<?php echo base_url()?>assets/front/sub-images/about-bnr.jpg)">
    <div class="container">
      <h1>EVENTS</h1>
    </div>  
  </div> <!-- sub banner --> 
  
  
<div class="from-bg">
    <div class="container pad-b48">
        <div class="row shadow bg-1">
            <div class="sub-cont committee"><h1 class="text-center">SHREE PM NARENDRA MODI FELICITATING AT VPAG</h1>
                <div class="row">
                    <div class="col-sm-3 col-ms-6 col-xs-12">
                      <div class="guests">
                        <img src="<?php echo base_url()?>assets/front/sub-images/vpag- modi-2.jpg" class="img-responsive" title="kensaku konishi" alt="Hideihiko Tanaka"> 
                        <a href="<?php echo base_url()?>assets/front/sub-images/vpag- modi-2.jpg" class="fancybox" data-fancybox-group="gallery">
                        <span class="hover-content"><i class="fa fa-expand"></i></span></a>
                      </div>
                    </div>
                    <div class="col-sm-3 col-ms-6 col-xs-12">
                      <div class="guests">
                        <img src="<?php echo base_url()?>assets/front/sub-images/vpag- modi-3.jpg" class="img-responsive" title="Pankaj Patel" alt="Hideihiko Tanaka"> 
                        <a href="<?php echo base_url()?>assets/front/sub-images/vpag- modi-3.jpg" class="fancybox" data-fancybox-group="gallery">
                        <span class="hover-content"><i class="fa fa-expand"></i></span></a>
                      </div>
                    </div>
                    <div class="col-sm-3 col-ms-6 col-xs-12">
                      <div class="guests">
                        <img src="<?php echo base_url()?>assets/front/sub-images/vpag- modi-4.jpg" class="img-responsive" title="PVN Moorthy" alt="PVN Moorthy"> 
                        <a href="<?php echo base_url()?>assets/front/sub-images/vpag- modi-4.jpg" class="fancybox" data-fancybox-group="gallery">
                        <span class="hover-content"><i class="fa fa-expand"></i></span></a>
                      </div>
                    </div>
                    <div class="col-sm-3 col-ms-6 col-xs-12">
                      <div class="guests">
                        <img src="<?php echo base_url()?>assets/front/sub-images/vpag- modi-5.jpg" class="img-responsive" title="Jai Narayan Vyas" alt="Jai Narayan Vyas"> 
                        <a href="<?php echo base_url()?>assets/front/sub-images/vpag- modi-5.jpg" class="fancybox" data-fancybox-group="gallery">
                        <span class="hover-content"><i class="fa fa-expand"></i></span></a>
                      </div>
                    </div>
                  </div><!--EVENTS end-->

            </div>
        </div>
    </div>
</div>  <!--from-bg end-->

