<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Part_master extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('SystemModel');
       
                
        $adminData = $this->session->userdata('adminData');
        if(!isset($adminData)){
             redirect('admin/Login');
        } 
       
    }
    
    public function index() {        
         
//        $modelData['tableName'] = 'part_master';
//        $data['AllPartList'] = $this->SystemModel->getAll($modelData);  
        
        
         $modelData['select'] = 'pa.*, cm.customer_name, cm.contact';
         $modelData['tableName'] = 'part_master pa';
         $modelData['join'][] = array('tableName' => 'customer_master cm', 'condtion' => 'cm.id=pa.customer_id', 'type'=>'left');
         $data['AllPartList'] = $this->SystemModel->getAll($modelData); 

        $this->load->admin('part_master/index',$data);
    }
    
    public function add_edit($id = '') {
//        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        $data = array();
        if($id != ''){
            $modelData['tableName'] = 'part_master';
            $modelData['condtion'] = "id=".$id;
            $data['PartDetail'] = $this->SystemModel->getOne($modelData);
        }

        $AllCustomerData['tableName'] = 'customer_master';
        $AllCustomerData['condtion'] = "status='Active'";
        $data['AllCustomer'] = $this->SystemModel->getAll($AllCustomerData);

        $this->load->admin('part_master/add_edit', $data);
    }
    
    
    public function action() {
//        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        extract($this->input->post()); // convert array to variable -- php function //
        
        $modelData['tableName'] = "part_master";
            
        if (isset($id) && $id != '') {                
            $modelData['data'] = array(                  
                        'customer_id' => $customer_id,
                        'part_name' => $part_name,
//                        'part_code' => $part_code,
                        'status' => $status,
                        'updated' => date('Y-m-d H:i:s')
                );
            $modelData['condtion'] = "id=" . $id;
            $result = $this->SystemModel->updateData($modelData);
            $successMessage = "Record updated successfully";
            $errorMessage = "No recoard updated";
            
        }else{
            
            $modelData['data'] = array(   
                        'customer_id' => $customer_id, 
                        'part_name' => $part_name,
//                        'part_code' => $part_code,
                        'status' => $status,
                        'created' => date('Y-m-d H:i:s')
                );
            $result = $this->SystemModel->insertData($modelData);
            $inserted_client_id = $this->SystemModel->lastInsertId();
            
            $part_code = sprintf("PART#%04d", $inserted_client_id);
            
            $modelData['data'] = array(     
                                        'part_code'    => $part_code,
            );
            $modelData['condtion'] = "id=" . $inserted_client_id;
            $result = $this->SystemModel->updateData($modelData);
            
            
            $successMessage = "Record added successfully";
            $errorMessage = "No added updated";
        } 
        
        if ($result) {
            $this->session->set_flashdata('success', $successMessage);
        } else {
            $this->session->set_flashdata('error', $errorMessage);
        }
        redirect('admin/part_master');        
    }
    
   
    public function delete($id) {
//        $this->SystemModel->checkAccess('car_brand_delete');// role access management
        
            /************** Delete Part master Detail *************/
        
            $modelData['tableName'] = "part_master";
            $modelData['condtion'] = "id=" . $id;
            $result = $this->SystemModel->deleteData($modelData);
            
            $successMessage = "Record deleted successfully";
            $errorMessage = "No record deleted";

            if ($result) {
                $this->session->set_flashdata('success', $successMessage);
            } else {
                $this->session->set_flashdata('error', $errorMessage);
            }
            redirect('admin/part_master');
        
    }   
    
}


