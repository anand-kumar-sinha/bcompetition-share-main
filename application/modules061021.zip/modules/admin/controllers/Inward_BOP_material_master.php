<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Inward_BOP_material_master extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('SystemModel');

        $adminData = $this->session->userdata('adminData');
        if (!isset($adminData)) {
            redirect('admin/Login');
        }
    }

    public function index()
    {

        $modelData['tableName'] = 'inward_BOP_material_master';
        $data['AllInwardBOP'] = $this->SystemModel->getAll($modelData);
        $this->load->admin('inward_BOP_material_master/index', $data);
    }

    public function add_edit($id = '')
    {
        //        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        $data = array();
        if ($id != '') {
            $modelData['tableName'] = 'inward_BOP_material_master';
            $modelData['condtion'] = "id=" . $id;
            $data['InwardBOPDetail'] = $this->SystemModel->getOne($modelData);
        }
        $this->load->admin('inward_BOP_material_master/add_edit', $data);
    }


    public function action()
    {
        //        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        extract($this->input->post()); // convert array to variable -- php function //

        $modelData['tableName'] = "inward_BOP_material_master";
        if (isset($id) && $id != '') {

            $modelData['data'] = array(
                'inward_material_name' => $inward_material_name,
//                'BOP_code' => $BOP_code,
                'description'  => $description,
                'status'      => $status,
                'updated'      => date('Y-m-d H:i:s')
            );
            $modelData['condtion'] = "id=" . $id;
            $result = $this->SystemModel->updateData($modelData);
            $successMessage = "Record updated successfully";
            $errorMessage = "No recoard updated";
        } else {
            
            $modelData['data'] = array(
                'inward_material_name' => $inward_material_name,
//                'BOP_code' => $BOP_code,
                'description'  => $description,
                'status'      => $status,
                'created'      => date('Y-m-d H:i:s')
            );
            $result = $this->SystemModel->insertData($modelData);
            $inserted_client_id = $this->SystemModel->lastInsertId();
            
            $BOP_code = sprintf("BOP#%04d", $inserted_client_id);
            
            $modelData['data'] = array(     
                                        'BOP_code'    => $BOP_code,
            );
            $modelData['condtion'] = "id=" . $inserted_client_id;
            $result = $this->SystemModel->updateData($modelData);
            
            
            $successMessage = "Record added successfully";
            $errorMessage = "No added updated";
        }

        if ($result) {
            $this->session->set_flashdata('success', $successMessage);
        } else {
            $this->session->set_flashdata('error', $errorMessage);
        }
        redirect('admin/inward_BOP_material_master/');
    }

    public function delete($id)
    {
        //        $this->SystemModel->checkAccess('car_brand_delete');// role access management

        /************** Delete Client Detail *************/

        $modelData['tableName'] = "inward_BOP_material_master";
        $modelData['condtion'] = "id=" . $id;
        $result = $this->SystemModel->deleteData($modelData);

        $successMessage = "Record deleted successfully";
        $errorMessage = "No record deleted";

        if ($result) {
            $this->session->set_flashdata('success', $successMessage);
        } else {
            $this->session->set_flashdata('error', $errorMessage);
        }
        redirect('admin/inward_BOP_material_master');
    }
}
