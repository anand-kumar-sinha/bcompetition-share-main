<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Operation_master extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('SystemModel');
       
                
        $adminData = $this->session->userdata('adminData');
        if(!isset($adminData)){
             redirect('admin/Login');
        } 
       
    }
    
    public function index() {        
         
        $modelData['tableName'] = 'operation_master';
        $data['AllOperationList'] = $this->SystemModel->getAll($modelData);  
        
        $this->load->admin('operation_master/index',$data);
    }
    
    public function add_edit($id = '') {
//        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        $data = array();
        if($id != ''){
            $modelData['tableName'] = 'operation_master';
            $modelData['condtion'] = "id=".$id;
            $data['OperationDetail'] = $this->SystemModel->getOne($modelData);
        }

        $this->load->admin('operation_master/add_edit', $data);
    }
    
    
    public function action() {
//        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        extract($this->input->post()); // convert array to variable -- php function //
        
        $modelData['tableName'] = "operation_master";
            
        if (isset($id) && $id != '') {                
            $modelData['data'] = array(  
                        'operation_name' => $operation_name,
//                        'operation_code' => $operation_code,
                        'status' => $status,
                        'updated' => date('Y-m-d H:i:s')
                );
            $modelData['condtion'] = "id=" . $id;
            $result = $this->SystemModel->updateData($modelData);
            $successMessage = "Record updated successfully";
            $errorMessage = "No recoard updated";
            
        }else{
            
            $modelData['data'] = array(    
                        'operation_name' => $operation_name,
//                        'operation_code' => $operation_code,
                        'status' => $status,
                        'created' => date('Y-m-d H:i:s')
                );
            $result = $this->SystemModel->insertData($modelData);
            $inserted_client_id = $this->SystemModel->lastInsertId();
            
            $operation_code = sprintf("OPE#%04d", $inserted_client_id);
            
            $modelData['data'] = array(     
                                        'operation_code'    => $operation_code,
            );
            $modelData['condtion'] = "id=" . $inserted_client_id;
            $result = $this->SystemModel->updateData($modelData);
            
            
            $successMessage = "Record added successfully";
            $errorMessage = "No added updated";
        } 
        
        if ($result) {
            $this->session->set_flashdata('success', $successMessage);
        } else {
            $this->session->set_flashdata('error', $errorMessage);
        }
        redirect('admin/operation_master');        
    }
    
   
    public function delete($id) {
//        $this->SystemModel->checkAccess('car_brand_delete');// role access management
        
            /************** Delete Part master Detail *************/
        
            $modelData['tableName'] = "operation_master";
            $modelData['condtion'] = "id=" . $id;
            $result = $this->SystemModel->deleteData($modelData);
            
            $successMessage = "Record deleted successfully";
            $errorMessage = "No record deleted";

            if ($result) {
                $this->session->set_flashdata('success', $successMessage);
            } else {
                $this->session->set_flashdata('error', $errorMessage);
            }
            redirect('admin/operation_master');
        
    }   
    
}


