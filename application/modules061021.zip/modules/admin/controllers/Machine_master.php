<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Machine_master extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('SystemModel');

        $adminData = $this->session->userdata('adminData');
        if (!isset($adminData)) {
            redirect('admin/Login');
        }
    }

    public function index()
    {

        $modelData['tableName'] = 'machine_master';
        $data['AllMachine'] = $this->SystemModel->getAll($modelData);
        $this->load->admin('machine_master/index', $data);
    }

    public function add_edit($id = '')
    {
        //        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        $data = array();
        if ($id != '') {
            $modelData['tableName'] = 'machine_master';
            $modelData['condtion'] = "id=" . $id;
            $data['MachineDetail'] = $this->SystemModel->getOne($modelData);
        }
        $this->load->admin('machine_master/add_edit', $data);
    }


    public function action()
    {
        //        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        extract($this->input->post()); // convert array to variable -- php function //

        $modelData['tableName'] = "machine_master";

        $uploadPath = FCPATH . 'uploads/machine_image/';
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0755, true);
        }

        if (isset($id) && $id != '') {

            if ($_FILES['check_sheet']['name'] != '') {
                $check_sheet = $this->SystemModel->imageUpload('check_sheet', $uploadPath);
                $path = FCPATH . 'uploads/machine_image/';
                unlink($path);
            } else {
                $check_sheet = $old_check_sheet;
            }
            $modelData['data'] = array(
                'machine_name' => $machine_name,
//                'machine_code' => $machine_code,
                'company_name'  => $company_name,
                'capacity'       => $capacity,
                'year'     => $year,
                'status'      => $status,
                'updated'      => date('Y-m-d H:i:s')
            );
            $modelData['condtion'] = "id=" . $id;
            $result = $this->SystemModel->updateData($modelData);
            $successMessage = "Record updated successfully";
            $errorMessage = "No recoard updated";
        } else {
            $company_logo = '';
            if (isset($_FILES['company_logo']['name']) && $_FILES['company_logo']['name'] != '') {
                $company_logo = $this->SystemModel->imageUpload('company_logo', $uploadPath);
            }
            $modelData['data'] = array(
                'machine_name' => $machine_name,
//                'machine_code' => $machine_code,
                'company_name'  => $company_name,
                'capacity'       => $capacity,
                'year'     => $year,
                'status'      => $status,
                'created'      => date('Y-m-d H:i:s')
            );
            $result = $this->SystemModel->insertData($modelData);
            $inserted_client_id = $this->SystemModel->lastInsertId();
            
            $machine_code = sprintf("MAC#%04d", $inserted_client_id);
            
            $modelData['data'] = array(     
                                        'machine_code'    => $machine_code,
            );
            $modelData['condtion'] = "id=" . $inserted_client_id;
            $result = $this->SystemModel->updateData($modelData);
            
            $successMessage = "Record added successfully";
            $errorMessage = "No added updated";
        }

        if ($result) {
            $this->session->set_flashdata('success', $successMessage);
        } else {
            $this->session->set_flashdata('error', $errorMessage);
        }
        redirect('admin/machine_master/');
    }

    public function delete($id)
    {
        //        $this->SystemModel->checkAccess('car_brand_delete');// role access management

        /************** Delete Client Detail *************/

        $modelData['tableName'] = "machine_master";
        $modelData['condtion'] = "id=" . $id;
        $result = $this->SystemModel->deleteData($modelData);

        $successMessage = "Record deleted successfully";
        $errorMessage = "No record deleted";

        if ($result) {
            $this->session->set_flashdata('success', $successMessage);
        } else {
            $this->session->set_flashdata('error', $errorMessage);
        }
        redirect('admin/machine_master');
    }
}
