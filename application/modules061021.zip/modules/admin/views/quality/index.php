<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-left">
                        <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>admin/Dashboard">Dashboard</a></li>
                        <li class="breadcrumb-item active">Quality List</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="col-sm-6 float-sm-left">
                                <h3 class="card-title">Quality List</h3>
                            </div>
                            <div class="col-sm-6 float-sm-right right-add">
                                <a class="top-btn right-button" href="<?php echo base_url() . 'admin/quality/add_edit/'; ?>" data-toggle="tooltip" data-placement="top" title="" data-original-title="Add">
                                    <button class="btn btn-primary btn-xs"><span class="fa fa-plus-circle"></span> Add</button>
                                </a>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Bom/PartName/Code/RM Form/RM Size</th>
                                        <th>Jobcard Number</th>
                                        <th>QC Inspector</th>
                                        <th>Inspected Qty</th>
                                        <th>Reject Qty</th>
                                        <th>Final Qty</th>
                                        <th>Date</th>
                                        <th style="width: 10%;">Status</th>
                                        <th class="no-sort center-text-table" style="width: 10%;">Action</th>
                                    </tr>
                                </thead>
                                <?php foreach ($AllQualityList as $_AllQualityList) {
                                    if ($_AllQualityList->status == "Active") {
                                        $btnClass = "btn-success";
                                    } else {
                                        $btnClass = "btn-danger";
                                    }
                                ?>
                                    <tr>
                                        <td><?php echo $_AllQualityList->bom_number . '/' . $_AllQualityList->part_name . '/' . $_AllQualityList->part_code . '/' . $_AllQualityList->rm_form . '/' . $_AllQualityList->rm_size; ?></td>
                                        <td><?php echo $_AllQualityList->job_card_number; ?></td>
                                        <td><?php echo $_AllQualityList->qc_inspector; ?></td>
                                        <td><?php echo $_AllQualityList->total_inspected_qty; ?></td>
                                        <td><?php echo $_AllQualityList->rejected_qty; ?></td>
                                        <td><?php echo $_AllQualityList->final_ok_qty; ?></td>
                                        <td><?php echo date("d-m-Y", strtotime($_AllQualityList->quality_date)); ?></td>
                                        <td>
                                            <button class="btn btn-block btn-xs <?php echo $btnClass; ?>"><?php echo $_AllQualityList->status; ?></button>
                                        </td>
                                        <td class="no-sort center-text-table">
                                            <a href="<?php echo base_url() . 'admin/quality/add_edit/' . $_AllQualityList->id; ?>" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                                <button class="btn btn-primary btn-xs"><i class="fas fa-edit"></i></button>
                                            </a>
                                            <a href="<?php echo base_url() . 'admin/quality/delete/' . $_AllQualityList->id; ?>" onclick="return confirm('Are you sure?');">
                                                <button class="btn btn-danger btn-xs"><i class="fas fa-trash-alt"></i></button>
                                            </a>
                                        </td>
                                    </tr>
                                <?php } ?>

                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->

                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->