<?php
if (isset($CompanyDetail)) {
    $id            = $CompanyDetail->id;
    $company_id  = $CompanyDetail->company_id;    
    $person_name  = $CompanyDetail->person_name;    
    $contact_no  = $CompanyDetail->contact_no;    
    $password  = $CompanyDetail->password;    
    $status  = $CompanyDetail->status;    
    $mode          = 'Edit';
            
} else {
    $id        = '';
    $company_name        = '';    
    $person_name        = '';    
    $contact_no        = '';    
    $password        = '';    
    $status        = '';    
    $mode      = 'Add';
}
?>  

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-left">
                        <li class="breadcrumb-item"><a href="<?php echo base_url();?>super_admin/Dashboard">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo base_url();?>super_admin/Company_admin">Company Admin List</a></li>
                        <li class="breadcrumb-item active"><?php echo $mode; ?> Company Admin</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

     <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title"><?php echo $mode; ?> Company Admin</h3>
        </div>
        <div class="card-body">
            <form id="company-master" method="post" action="<?php echo base_url();?>super_admin/Company_admin/action" enctype="multipart/form-data" novalidate="novalidate">
                <!-- Start : Company Details -->
                <input type="hidden" id="id" name="id" value="<?php echo $id;?>">
                <!-- Start ROW -->
                <div class="row"> 
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Company Name</label>
                            <select name="company_id" class="custom-select select2">
                                <?php foreach ($AllCompany as $_AllCompany) { 
                                        $selected = "";
                                        if($_AllCompany->id == $company_id){
                                            $selected = "selected";
                                        }
                                    ?> 
                                <option value="<?php echo $_AllCompany->id;?>" <?php echo $selected; ?>><?php echo $_AllCompany->company_name;?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Person Name</label>
                            <input type="text" class="form-control" id="person_name" name="person_name" value="<?php echo $person_name;?>">
                        </div>
                    </div>
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Contact No</label>
                            <input type="text" class="form-control" id="contact_no" name="contact_no" value="<?php echo $contact_no;?>" onchange="UniqueAdmin(this.value);">
                            <span id="error" class="error" style="display: none;"> Enter Unique Contact No</span><br>
                            <span id="success" class="success" style="display: none; color: green;">Unique Contact No </span><br>
                        </div>
                    </div>
                </div>
                <!-- End ROW -->
                <!-- Start ROW -->
                <div class="row">
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Password</label>
                            <input tabindex="1" size="40" class="form-control" type="password" name="password" id="password" />
                            <input type="hidden" class="form-control" id="old_password" name="old_password" value="<?php echo $password;?>">
                            <?php if($mode == "Edit"){echo "If you don't want to change password, <br />Leave it blank.";}?>
                        </div>
                    </div>
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input tabindex="1" class="form-control" size="40" type="password" name="cpassword" id="cpassword" />
                        </div>
                    </div>
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status" id="status" class="custom-select">
                                <option value="Active" <?php if($status=="Active"){ echo "selected";}?>>Active</option>
                                <option value="Deactive"  <?php if($status=="Deactive"){ echo "selected";}?>>Deactive</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- End ROW -->
                <!-- End : Company Details -->
                <div class="box-footer">
                    <button type="button" class="btn btn-secondary" onclick="window.history.back();">Cancel</button>
                    <button type="submit" id="SubmitBtn" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
        <!-- /.card-body -->
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<style>
      .error{
          color: red;
      }
</style>
<script>
      
function UniqueAdmin(admin_contact) {
    $.ajax({
        url:"<?php echo base_url() . "super_admin/Company_admin/unique_admin"; ?>",
        method:"POST", 
        data:{contact_no:admin_contact},
        success:function(data)
        {
             if(data == 0){
                 $("#error").hide();
                $("#success").show();
                $("#SubmitBtn").show();
             } else {
                $("#error").show();
                $("#success").hide();
                $("#SubmitBtn").hide();
               
             }
        }
    });
}

$( document ).ready(function() {
    $('.select2').select2();
    $(function() {
  
    // Setup form validation on the #register-form element
    $("#company-master").validate({
        // Specify the validation rules
        rules: {
            company_name:"required",
            person_name:"required",
            contact_no: {
                required: true,
                number: true,
                minlength: 10,
                maxlength: 10,
            },
            password: {
                <?php if($mode == "Add"){ ?>
                    required: true,
                <?php } ?>
                    minlength: 6
            },
            cpassword : {
                equalTo : "#password",
            },
        },
        
        // Specify the validation error messages
        messages: {
            company_name:"Please enter company name",
            person_name:"Please enter person name",
            contact_no: {
                required: "Enter Contact No",
                number: "Enter only number",
                maxlength: "Please enter maximum 10 latters in Number",
                minlength: "Please enter minimum 10 latters in Number",
            },
             password: {
                required: "Please enter a valid password",
                minlength: "Your password must be at least 6 characters long",
            },
            cpassword : {
                equalTo : "Passwords do not match."
            },
        }
        
    });

  });
});



</script>
