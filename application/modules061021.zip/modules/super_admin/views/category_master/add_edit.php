<?php
if (isset($CategoryDetail)) {
    $id            = $CategoryDetail->id;
    $category_name  = $CategoryDetail->category_name;    
    $mode          = 'Edit';
            
} else {
    $id        = '';
    $category_name        = '';    
    $mode      = 'Add';
}
?>  

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-left">
                        <li class="breadcrumb-item"><a href="<?php echo base_url();?>admin/Dashboard">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo base_url();?>admin/Category_master">Category List</a></li>
                        <li class="breadcrumb-item active"><?php echo $mode; ?> Client</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="col-sm-6 float-sm-left">
                                <h3 class="card-title"><?php echo $mode; ?> Client</h3>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <form id="client-form" method="post" action="<?php echo base_url() ?>admin/Category_master/action" enctype="multipart/form-data">
                                <input type="hidden" id="id" name="id" value="<?php echo $id; ?>" />
                                <!-- Start ROW -->
                                <div class="row">
                                    <div class="col-md-3"> 
                                        <div class="form-group">
                                            <label>Category Name</label>
                                            <input style="text-transform: capitalize;" type="text" class="form-control" id="category_name" name="category_name" value="<?php echo $category_name; ?>" >
                                        </div>
                                    </div>                                    
                                </div>
                                <!-- End ROW -->
                              
                                <hr>
                                <div class="box-footer">
                                    <button type="button" class="btn btn-secondary" onclick="window.history.back();">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->

                </div>
                <!-- /.col -->
            </div>
          
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->



<div id="AddEditContactNumberDiv"></div>
<div id="AddEditAddressDiv"></div>
<div id="AddEditClientEmailDiv"></div>



<style>
      .error{
          color: red;
      }
</style>
<script>
    $('#ContactNumber').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
    });
        
    $('#Address').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
    });
        
    $('#ClientEmail').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
    });
        
    $('#date_of_birth').datepicker({
        todayHighlight: true,
        format: "d-m-yyyy",
        autoclose: true
    });   
    $('#anniversary_date').datepicker({
        todayHighlight: true,
        format: "d-m-yyyy",
        autoclose: true
    });   
        
//  $(function() {
//    var start_year = new Date().getFullYear();
//    var birth_year_db = '<?php //echo $birth_year_db;?>';
//    for (var i = start_year; i > start_year - 100; i--) {
//        var selected = '';
//       if(i == birth_year_db){
//           selected = "selected";
//       }
//      $('#birth_year').append('<option value="' + i + '"'+selected+'>' + i + '</option>');
//    }
//  });
//  
//  $(function() {
//    var start_year = new Date().getFullYear();
//    var anniversary_year_db = '<?php // echo $anniversary_year_db;?>';
//    
//    for (var i = start_year; i > start_year - 100; i--) {
//        var selected = '';
//       if(i == anniversary_year_db){
//           selected = "selected";
//       }
//       
//      $('#anniversary_year').append('<option value="' + i + '"'+selected+'>' + i + '</option>');
//    }
//  });
//    
    
  
$( document ).ready(function() {
    
    $(function() {
  
    // Setup form validation on the #register-form element
    $("#client-form").validate({
        // Specify the validation rules
        rules: {
            first_name:"required",
            middle_name:"required",
            last_name:"required",
           
            
        },
        
        // Specify the validation error messages
        messages: {
            first_name:"Please enter a first name",
            middle_name:"Please enter a middle name",
            last_name:"Please Selects a last name",

        }
        
    });

  });
});


///////////////////////////////////////////////
////// Start: Client Contact Number //////////
//////////////////////////////////////////////




function AddContactNumber() {
     var mode = "add";
     var client_id = '<?php echo $client_id;?>';
     $.ajax({
         type: "POST",
         url: '<?php echo base_url() . "admin/Client_master/contact_number_add"; ?>',
         data: {mode:mode,client_id:client_id}, 
         success: function(data){
             $("#AddEditContactNumberDiv").html(data);
             $('#AddContactNumberModel').modal('show');
         },
     });
 }
 
function EditContactNumber(contact_number_id) {
     var mode = "edit";
     var client_id = '<?php echo $client_id;?>';
    $.ajax({
         type: "POST",
         url: '<?php echo base_url() . "admin/Client_master/contact_number_edit"; ?>',
         data: {mode:mode,client_id:client_id,contact_number_id:contact_number_id}, 
         success: function(data){
             $("#AddEditContactNumberDiv").html(data);
             $('#EditContactNumberModel').modal('show');
         },
    });
 }



function DeleteContactNumber(contact_number_id){
    var confirmation = confirm("are you sure you want to remove ?");
     if (confirmation) {
         $.ajax({
              type: "POST",
              url: '<?php echo base_url() . "admin/Client_master/contact_number_delete"; ?>',
              data: {contact_number_id:contact_number_id}, 
              success: function(data){
                  if(data == 1){
                      $("#ContactNumberRow"+contact_number_id).fadeOut(500);
                  }
              },
          });
     }
}


///////////////////////////////////////////////
////// End: Client Contact Number //////////
//////////////////////////////////////////////






///////////////////////////////////////////////
////// Start: Client Address //////////
//////////////////////////////////////////////




function AddAddress() {
     var mode = "add";
     var client_id = '<?php echo $client_id;?>';
     $.ajax({
         type: "POST",
         url: '<?php echo base_url() . "admin/Client_master/address_add"; ?>',
         data: {mode:mode,client_id:client_id}, 
         success: function(data){
             $("#AddEditAddressDiv").html(data);
             $('#AddAddressModel').modal('show');
         },
     });
 }
 
function EditAddress(address_id) {
     var mode = "edit";
     var client_id = '<?php echo $client_id;?>';
    $.ajax({
         type: "POST",
         url: '<?php echo base_url() . "admin/Client_master/address_edit"; ?>',
         data: {mode:mode,client_id:client_id,address_id:address_id}, 
         success: function(data){
             $("#AddEditAddressDiv").html(data);
             $('#EditAddressModel').modal('show');
         },
    });
 }



function DeleteAddress(address_id){
    var confirmation = confirm("are you sure you want to remove ?");
     if (confirmation) {
         $.ajax({
              type: "POST",
              url: '<?php echo base_url() . "admin/Client_master/address_delete"; ?>',
              data: {address_id:address_id}, 
              success: function(data){
                  if(data == 1){
                      $("#AddressRow"+address_id).fadeOut(500);
                  }
              },
          });
     }
}




///////////////////////////////////////////////
////// End: Client Address //////////
//////////////////////////////////////////////




///////////////////////////////////////////////
////// Start: Client E-mails //////////
//////////////////////////////////////////////



function AddClientEmail() {
     var mode = "add";
     var client_id = '<?php echo $client_id;?>';
     $.ajax({
         type: "POST",
         url: '<?php echo base_url() . "admin/Client_master/client_email_add"; ?>',
         data: {mode:mode,client_id:client_id}, 
         success: function(data){
             $("#AddEditClientEmailDiv").html(data);
             $('#AddClientEmailModel').modal('show');
         },
     });
 }
 
function EditClientEmail(client_email_id) {
     var mode = "edit";
     var client_id = '<?php echo $client_id;?>';
    $.ajax({
         type: "POST",
         url: '<?php echo base_url() . "admin/Client_master/client_email_edit"; ?>',
         data: {mode:mode,client_id:client_id,client_email_id:client_email_id}, 
         success: function(data){
             $("#AddEditClientEmailDiv").html(data);
             $('#EditClientEmailModel').modal('show');
         },
    });
 }



function DeleteClientEmail(client_email_id){
    var confirmation = confirm("are you sure you want to remove ?");
     if (confirmation) {
         $.ajax({
              type: "POST",
              url: '<?php echo base_url() . "admin/Client_master/client_email_delete"; ?>',
              data: {client_email_id:client_email_id}, 
              success: function(data){
                  if(data == 1){
                      $("#ClientEmailRow"+client_email_id).fadeOut(500);
                  }
              },
          });
     }
}


///////////////////////////////////////////////
////// End: Client E-mails //////////
//////////////////////////////////////////////
</script>
