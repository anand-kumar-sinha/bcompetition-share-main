<?php
if (isset($CompanyDetail)) {
    $id            = $CompanyDetail->id;
    $company_name  = $CompanyDetail->company_name;    
    $person_name  = $CompanyDetail->person_name;    
    $contact_no  = $CompanyDetail->contact_no;    
    $email  = $CompanyDetail->email;    
    $address  = $CompanyDetail->address;    
    $gst  = $CompanyDetail->gst;    
    $pan_number  = $CompanyDetail->pan_number;    
    $partnership_proprietor_ship  = $CompanyDetail->partnership_proprietor_ship;    
    $company_logo  = $CompanyDetail->company_logo;    
    $status  = $CompanyDetail->status;    
    $mode          = 'Edit';
            
} else {
    $id        = '';
    $company_name        = '';    
    $person_name        = '';    
    $contact_no        = '';    
    $email        = '';    
    $address        = '';    
    $gst        = '';    
    $pan_number        = '';    
    $partnership_proprietor_ship        = '';    
    $company_logo        = '';    
    $status        = '';    
    $mode      = 'Add';
}
?>  

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-left">
                        <li class="breadcrumb-item"><a href="<?php echo base_url();?>super_admin/Dashboard">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo base_url();?>super_admin/Company_master">Company List</a></li>
                        <li class="breadcrumb-item active"><?php echo $mode; ?> Company</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

     <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Add Company</h3>
        </div>
        <div class="card-body">
            <form id="company-master" method="post" action="<?php echo base_url(); ?>/super_admin/Company_master/action" enctype="multipart/form-data" novalidate="novalidate">
                <!-- Start : Company Details -->
                <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">
                <!-- Start ROW -->
                <div class="row">
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Company Name</label>
                            <input type="text" class="form-control" id="company_name" name="company_name" value="<?php echo $company_name; ?>">
                        </div>
                    </div>
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Person Name</label>
                            <input type="text" class="form-control" id="person_name" name="person_name" value="<?php echo $person_name; ?>">
                        </div>
                    </div>
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Contact No</label>
                            <input type="text" class="form-control" id="contact_no" name="contact_no" value="<?php echo $contact_no; ?>" onchange="UniqueAdmin(this.value);">
                            <span id="error" class="error" style="display: none;"> Enter Unique Contact No</span><br>
                            <span id="success" class="success" style="display: none;  color: green;">Unique Contact No </span><br>
                        </div>
                    </div>
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>E-mail</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>">
                        </div>
                    </div>
                    
                </div>
                <!-- End ROW -->
                <!-- Start ROW -->
                <div class="row">
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Address</label>
                            <input type="text" class="form-control" id="address" name="address" value="<?php echo $address; ?>">
                        </div>
                    </div>
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>GST</label>
                            <input type="text" class="form-control" id="gst" name="gst" value="<?php echo $gst; ?>">
                        </div>
                    </div>
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Pan Number</label>
                            <input type="text" class="form-control" id="pan_number" name="pan_number" value="<?php echo $pan_number; ?>">
                        </div>
                    </div>
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Partnership / Proprietor Ship</label>
                            <select name="partnership_proprietor_ship" class="custom-select">
                                <option value="Partnership" <?php if($status == 'Partnership') echo 'selected'; ?>>Partnership</option>
                                <option value="Proprietor" <?php if($status == 'Proprietor') echo 'selected'; ?>>Proprietor</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- End ROW -->
                <!-- Start ROW -->
                <div class="row">
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Company Logo</label>
                            <input id="company_logo" name="company_logo" type="file" class="form-control">
                        </div>
                    </div>
                    <?php if(isset($company_logo) && $company_logo != '') { ?>
                        <div class="col-md-3"> 
                            <input type="hidden" name="old_default_image" value="<?php echo $company_logo; ?>">
                            <img src ="<?php echo base_url() ?>uploads/company_image/<?php echo $company_logo; ?>" width="100"/>
                        </div>
                    <?php } ?>
                    <div class="col-md-3"> 
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status" class="custom-select">
                                <option value="Active" <?php if($status == 'Active') echo 'selected'; ?>>Active</option>
                                <option value="Deactive" <?php if($status == 'Deactive') echo 'selected'; ?>>Deactive</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- End ROW -->
                <!-- End : Company Details -->
                <div class="box-footer">
                    <button type="button" class="btn btn-secondary" onclick="window.history.back();">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
        <!-- /.card-body -->
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<style>
      .error{
          color: red;
      }
</style>
<script>
      
$( document ).ready(function() {
    
    $(function() {
  
    // Setup form validation on the #register-form element
    $("#company-master").validate({
        // Specify the validation rules
        rules: {
            company_name:"required",
            person_name:"required",
            contact_no: {
                required: true,
                number: true,
                minlength: 10,
                maxlength: 10,
            },       
            email:"required",         
            address:"required",         
            gst:"required",         
            pan_number:"required",         
            partnership_proprietor_ship:"required",         
            status:"required"   
        },
        
        // Specify the validation error messages
        messages: {
            company_name:"Please enter company name",
            person_name:"Please enter person name",
           contact_no: {
                required: "Enter Contact No",
                number: "Enter only number",
                maxlength: "Please enter maximum 10 latters in Number",
                minlength: "Please enter minimum 10 latters in Number",
            },
            email:"Please enter email",
            address:"Please enter address",
            gst:"Please enter gst",
            pan_number:"Please enter pan number",
            partnership_proprietor_ship:"Please Selects",
            company_logo:"Please Selects logo",
            status:"Please Selects status"

        }
        
    });

  });
});

    
function UniqueAdmin(admin_contact) {
    $.ajax({
        url:"<?php echo base_url() . "super_admin/Company_admin/unique_admin"; ?>",
        method:"POST", 
        data:{contact_no:admin_contact},
        success:function(data)
        {
             if(data == 0){
                 $("#error").hide();
                $("#success").show();
             } else {
                $("#error").show();
                $("#success").hide();
               
             }
        }
    });
}
</script>
