<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Company_master extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('SystemModel');
                
        $superAdminData = $this->session->userdata('superAdminData');
        if(!isset($superAdminData)){
             redirect('super_admin/Login');
        } 
       
    }
    
    public function index() {        
         
        $modelData['tableName'] = 'company_master';
        $data['AllCompany'] = $this->SystemModel->getAll($modelData);         
        $this->load->super_admin('company_master/index',$data);
    }
    
    public function add_edit($id = '') {
//        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        $data = array();
        if($id != ''){
            $modelData['tableName'] = 'company_master';
            $modelData['condtion'] = "id=".$id;
            $data['CompanyDetail'] = $this->SystemModel->getOne($modelData);
        }
        $this->load->super_admin('company_master/add_edit', $data);
    }
 
    public function view($id) {
//        $this->SystemModel->checkAccess('car_brand_view');// role access management
        $data = array();
        $modelData['tableName'] = 'company_master';
        $modelData['condtion'] = "id=" . $id;
        $data['ClientDetail'] = $this->SystemModel->getOne($modelData);
       
        $this->load->super_admin('company_master/view', $data);
    }
    
    
    public function action() {
//        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        extract($this->input->post()); // convert array to variable -- php function //
        
        $modelData['tableName'] = "company_master";
        
        $uploadPath = FCPATH . 'uploads/company_image/';
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0755, true);
        }
        
        if (isset($id) && $id != '') {
            
            if ($_FILES['company_logo']['name'] != '') {
                $company_logo = $this->SystemModel->imageUpload('company_logo', $uploadPath);
                $path = FCPATH . 'uploads/company_image/';
                unlink($path);
            } else {
                $company_logo = $old_company_logo;
            }
            $modelData['data'] = array(  
                'company_name' => $company_name,
                'person_name' => $person_name,
                'contact_no'  => $contact_no,
                'email'       => $email,
                'address'     => $address,
                'gst'         => $gst,
                'pan_number'  => $pan_number,
                'partnership_proprietor_ship'    => $partnership_proprietor_ship,
                'company_logo'=> $company_logo,
                'status'      => $status,
                'updated'      => date('Y-m-d H:i:s')
            );
            $modelData['condtion'] = "id=" . $id;
            $result = $this->SystemModel->updateData($modelData);
            $successMessage = "Record updated successfully";
            $errorMessage = "No recoard updated";
            
        }else{
            $company_logo = '';
            if (isset($_FILES['company_logo']['name']) && $_FILES['company_logo']['name'] != '') {
                $company_logo = $this->SystemModel->imageUpload('company_logo', $uploadPath);
            }
            $modelData['data'] = array(  
                'company_name' => $company_name,
                'person_name' => $person_name,
                'contact_no'  => $contact_no,
                'email'       => $email,
                'address'     => $address,
                'gst'         => $gst,
                'pan_number'  => $pan_number,
                'partnership_proprietor_ship'    => $partnership_proprietor_ship,
                'company_logo'=> $company_logo,
                'status'      => $status,
                'created'      => date('Y-m-d H:i:s')
            );
            $result = $this->SystemModel->insertData($modelData);
            $successMessage = "Record added successfully";
            $errorMessage = "No added updated";
        } 
        
        if ($result) {
            $this->session->set_flashdata('success', $successMessage);
        } else {
            $this->session->set_flashdata('error', $errorMessage);
        }
        redirect('super_admin/Company_master/');        
    }
        
    public function delete($id) {
//        $this->SystemModel->checkAccess('car_brand_delete');// role access management
        
            /************** Delete Client Detail *************/
        
            $modelData['tableName'] = "company_master";
            $modelData['condtion'] = "id=" . $id;
            $result = $this->SystemModel->deleteData($modelData);
            
            $successMessage = "Record deleted successfully";
            $errorMessage = "No record deleted";

            if ($result) {
                $this->session->set_flashdata('success', $successMessage);
            } else {
                $this->session->set_flashdata('error', $errorMessage);
            }
            redirect('super_admin/Company_master');
        
    }   
    
    public function unique_admin() {
        
        extract($this->input->post()); // convert array to variable -- php function //
          
        $modelData['tableName'] = "company_master";
        $modelData['condtion'] = "contact_no='" . $contact_no."'";
        $result = $this->SystemModel->tableRowCount($modelData); 
        echo $result;
        die();
    }
    
}


