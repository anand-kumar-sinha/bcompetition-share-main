<?php

(defined('BASEPATH')) OR exit('No direct script access allowed');

/**
 * Description of site
 *
 * @author https://www.roytuts.com
 */
class Dashboard extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('SystemModel');
        $superAdminData = $this->session->userdata('superAdminData');
        if(!isset($superAdminData)){
             redirect('super_admin/Login');
        }	
    }
    
    function index() {
        extract($this->input->post()); // convert array to variable -- php function //
        
        $CompanyData['tableName'] = "company_master";
//        $custData['condtion'] = "status='Active'";
        $data['TotalCompany'] = $this->SystemModel->getAll($CompanyData);
        
        $CompanyAdminData['tableName'] = "company_admin";
//        $custData['condtion'] = "status='Active'";
        $data['TotalCompanyAdmin'] = $this->SystemModel->getAll($CompanyAdminData);

        $this->load->super_admin('dashboard/index', $data);
    }

}

/* End of file Site.php */
/* Location: ./application/modules/site/controllers/site.php */