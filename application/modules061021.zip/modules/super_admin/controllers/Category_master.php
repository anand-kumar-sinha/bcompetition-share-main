<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Category_master extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('SystemModel');
       
                
        $adminData = $this->session->userdata('adminData');
        if(!isset($adminData)){
             redirect('admin/Login');
        } 
       
    }
    
    public function index() {        
         
        $modelData['tableName'] = 'category_master';
        $data['AllCategory'] = $this->SystemModel->getAll($modelData);         
        $this->load->admin('category_master/index',$data);
    }
    
    public function add_edit($id = '') {
//        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        $data = array();
        if($id != ''){
            $modelData['tableName'] = 'category_master';
            $modelData['condtion'] = "id=".$id;
            $data['CategoryDetail'] = $this->SystemModel->getOne($modelData);
        }
        $this->load->admin('category_master/add_edit', $data);
    }
 
    public function view($id) {
//        $this->SystemModel->checkAccess('car_brand_view');// role access management
        $data = array();
        $modelData['tableName'] = 'category_master';
        $modelData['condtion'] = "id=" . $id;
        $data['ClientDetail'] = $this->SystemModel->getOne($modelData);
       
        $this->load->admin('category_master/view', $data);
    }
    
    
    public function action() {
//        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        extract($this->input->post()); // convert array to variable -- php function //
        
        $modelData['tableName'] = "category_master";
            
        if (isset($id) && $id != '') {                
            $modelData['data'] = array(  'category_name'    => $category_name );
            $modelData['condtion'] = "id=" . $id;
            $result = $this->SystemModel->updateData($modelData);
            $successMessage = "Record updated successfully";
            $errorMessage = "No recoard updated";
            
        }else{
            
            $modelData['data'] = array( 'category_name'    => $category_name );
            $result = $this->SystemModel->insertData($modelData);
            $successMessage = "Record added successfully";
            $errorMessage = "No added updated";
        } 
        
        if ($result) {
            $this->session->set_flashdata('success', $successMessage);
        } else {
            $this->session->set_flashdata('error', $errorMessage);
        }
        redirect('admin/Category_master');        
    }
    
   
    
    
    public function delete($id) {
//        $this->SystemModel->checkAccess('car_brand_delete');// role access management
        
            /************** Delete Client Detail *************/
        
            $modelData['tableName'] = "category_master";
            $modelData['condtion'] = "id=" . $id;
            $result = $this->SystemModel->deleteData($modelData);
            
            $successMessage = "Record deleted successfully";
            $errorMessage = "No record deleted";

            if ($result) {
                $this->session->set_flashdata('success', $successMessage);
            } else {
                $this->session->set_flashdata('error', $errorMessage);
            }
            redirect('admin/Category_master');
        
    }   
    
}


