<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Company_admin extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('SystemModel');
                
        $superAdminData = $this->session->userdata('superAdminData');
        if(!isset($superAdminData)){
             redirect('super_admin/Login');
        } 
       
    }
    
    public function index() {        
         
        $modelData['select'] = 'ca.*, cm.company_name';
        $modelData['tableName'] = 'company_admin ca';
        $modelData['join'][] = array('tableName' => 'company_master cm', 'condtion' => 'cm.id=ca.company_id', 'type'=>'left');
        $data['AllCompany'] = $this->SystemModel->getAll($modelData);         
        $this->load->super_admin('company_admin/index',$data);
    }
    
    public function add_edit($id = '') {
//        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        $data = array();
        if($id != ''){
            $modelData['tableName'] = 'company_admin';
            $modelData['condtion'] = "id=".$id;
            $data['CompanyDetail'] = $this->SystemModel->getOne($modelData);
        }
        
        $AllCompanyData['tableName'] = 'company_master';
        $AllCompanyData['condtion'] = "status='Active'";
        $data['AllCompany'] = $this->SystemModel->getAll($AllCompanyData);
        
        $this->load->super_admin('company_admin/add_edit', $data);
    }
 
    public function view($id) {
//        $this->SystemModel->checkAccess('car_brand_view');// role access management
        $data = array();
        $modelData['tableName'] = 'company_admin';
        $modelData['condtion'] = "id=" . $id;
        $data['ClientDetail'] = $this->SystemModel->getOne($modelData);
       
        $this->load->super_admin('company_admin/view', $data);
    }
    
    
    public function action() {
//        $this->SystemModel->checkAccess('car_brand_add_edit');// role access management
        extract($this->input->post()); // convert array to variable -- php function //
        
        $modelData['tableName'] = "company_admin";
        
        if (isset($id) && $id != '') {
            
        if(isset($password) && $password !=''){
            $password = md5($password);
        } else {
            $password = $old_password;
        }
            $modelData['data'] = array(  
                                        'company_id' => $company_id,
                                        'person_name' => $person_name,
                                        'contact_no'  => $contact_no,
                                        'password'       => $password,
                                        'status'      => $status,
                                        'updated'      => date('Y-m-d H:i:s')
            );
            $modelData['condtion'] = "id=" . $id;
            $result = $this->SystemModel->updateData($modelData);
            $successMessage = "Record updated successfully";
            $errorMessage = "No recoard updated";
            
        }else{
           
            $modelData['data'] = array(  
                                            'company_id' => $company_id,
                                            'person_name' => $person_name,
                                            'contact_no'  => $contact_no,
                                            'password'       => md5($password),
                                            'status'      => $status,
                                            'created'      => date('Y-m-d H:i:s')
            );
            $result = $this->SystemModel->insertData($modelData);
            $successMessage = "Record added successfully";
            $errorMessage = "No added updated";
        } 
        
        if ($result) {
            $this->session->set_flashdata('success', $successMessage);
        } else {
            $this->session->set_flashdata('error', $errorMessage);
        }
        redirect('super_admin/Company_admin/');        
    }
       
    public function unique_admin() {
        
        extract($this->input->post()); // convert array to variable -- php function //
          
        $modelData['tableName'] = "company_admin";
        $modelData['condtion'] = "contact_no='" . $contact_no."'";
        $result = $this->SystemModel->tableRowCount($modelData); 
        echo $result;
        die();
    }
    
    public function delete($id) {
//        $this->SystemModel->checkAccess('car_brand_delete');// role access management
        
            /************** Delete Client Detail *************/
        
            $modelData['tableName'] = "company_admin";
            $modelData['condtion'] = "id=" . $id;
            $result = $this->SystemModel->deleteData($modelData);
            
            $successMessage = "Record deleted successfully";
            $errorMessage = "No record deleted";

            if ($result) {
                $this->session->set_flashdata('success', $successMessage);
            } else {
                $this->session->set_flashdata('error', $errorMessage);
            }
            redirect('super_admin/Company_admin');
        
    }   
    
}


